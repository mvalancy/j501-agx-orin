# J501 AGX enclosure — Rev 0.4 fit-check prototype

Local review: **http://127.0.0.1:43871/preview/**. Open `preview/server-url.txt` for the current port. The engineering tables are in [docs/engineering-review.html](docs/engineering-review.html); the dimensioned paper review is [docs/check-sheet.pdf](docs/check-sheet.pdf).

This design targets the **original Seeed reServer Industrial J501, SKU102991854, 176 × 163 mm**, with optional GMSL board SKU102991855. It does not use the Mini/Robotics carrier outline. The user's cooler is not identified conclusively: Seeed 100099421 (110 × 100 × 50 mm) is a reference envelope, not confirmed user hardware.

The current design uses an 8 mm floor, 6 mm walls/panels and a 2.4 mm-wide × 10 mm-deep roof grid, integrated printed PCB supports, rigid sliding panel rails and **two M6 cover screws**. Supplier references and the simplified model differences are in [docs/fastener-sources.csv](docs/fastener-sources.csv). Four M3 screws secure the carrier to inserts in the printed supports. There are no loose carrier spacers, panel screws, hatch screws or mounting-ear screws. Existing cooler/module and GMSL retention hardware remains separate and must be reused as appropriate.

## Open roof, exterior rounding and mounting clearance

The roof is **67.37% open** by projected CAD area (previously 25.58%): 2.633 times the opening area, with 32.63% closed area. There are 42 rounded openings and a connected grid of 2.4 mm-wide, 10 mm-deep upright webs. Reinforced corner lands stay over the panel-capture stops. The deeper ribs reduce nominal cooler clearance from 15.242 to 11.242 mm. This is an open-area calculation, not an airflow or whole-lid stiffness test. The rectangular rib bending section property is 200 mm4, versus 108–144 mm4 previously; changed spans, joints, layer adhesion and material still matter.

Exposed base corners have R3 fillets, lid corners R4, exterior rims R1.2 and panel exposed-face edges R0.6. Mounting pads have R4 vertical corners and R1.2 top edges; the hatch grip is rounded. Bed-contact faces, rib crests, rail reference faces, insert seats and 45-degree vent closures retain their functional geometry. Front panels now print **inner face down** so their exterior edge rounds build upward. The STL export removes only degenerate tessellation triangles when necessary, then checks watertightness; counts are recorded per part.

The tabs moved to the **front and rear** so extra projection fits a one-piece P1S print. Each is 40 mm wide, projects 30 mm beyond the base and is 16 mm thick. M6 slots are 12 mm along X by 6.6 mm wide. Their center pattern is **166 × 233 mm**, at `(20,-20)`, `(186,-20)`, `(20,213)`, `(186,213)` in enclosure XY. A 16 mm washer envelope fits the flat pad; a 20 mm-diameter driver envelope above Z24 clears the cover by 3.6 mm nominal. External anchor/screw length is still site-specific. See [exports/design-metrics.json](exports/design-metrics.json), the mounting-access render and PDF sheets 8–9.

## Parts and configurations

- Desktop: P1 `base`, P2 `cover`, either P3 `front_gmsl` or P4 `front_no_gmsl`, P5 `rear_io`, P10 `side_hatch`. Adhesive feet are optional and unselected.
- Wall/robot: substitute P1M `base_mount`, with integral 16 mm-thick front/rear mounting tabs. External M6 attachment hardware is site-specific; select length/anchors for the mounting surface and actual loads.
- Calibration: P8 M6 coupon, P11 M3 coupon, P12/P13 rail coupon/key, P9 board mount template. The 3 mm template is a measuring tool, not a structural enclosure part.

The P1M print envelope is 217 × 253 × 72 mm. P2 is 218.8 × 205.8 × 64 mm in print orientation. These are within the P1S's nominal 256 mm cube, but center the parts and check Bambu Studio's excluded areas, brim and first-layer path. The 253 mm dimension leaves only 1.5 mm nominal margin at each end when centered; a 5 mm brim will not fit. The user's filament remains unspecified; fits, heat resistance and insert retention are not qualified for a material yet.

## Assembly and retention

1. Print the insert and sliding-fit coupons with the intended filament/profile. Nominal pilots are M6 7.5 mm and M3 3.9 mm. The M6 pilot has pointed relief for horizontal printing. A successful coupon must guide the insert without splitting and retain it after cooling; exact installation temperature and torque are not prescribed.
2. Check P9 on the actual carrier. The 150 × 130 mm mount pattern is derived from manufacturer mounting proxies. Confirm the actual hole diameter, metal keepouts and permissible screw head before using the assumed M3 hardware.
3. Heat-set four user M3 × 10 inserts into the printed board supports and two M6 × 10 inserts into the cover-retention columns. Install inserts before electronics. Support lands must remain flat and free of displaced plastic.
4. Place the PCB on its four lands and fasten with M3 × 10 button heads. Nominal engagement is 10 − 1.578 = 8.422 mm. Do not use the enclosure fasteners to clamp the cooler. The broad 16 mm support transitions to a 7 mm landing for the final 4.5 mm to clear nearby underside parts.
5. Install the module and existing cooler retention using the four inner 92 × 79 mm positions and the hardware required by the actual cooler/module. The visual H7 screws illustrate the path; their diameter/length is not a replacement specification.
6. For GMSL, use its supplied supports and screws. Seeed's photos show two supports between carrier and addon. Their exact thread and length are not established here. The Samtec part suffixes imply 16 mm between facing PCB surfaces; verify the actual fitted parts.
7. Slide the front/rear panels and J17 hatch down their channels. The front plate is placed ahead of the most protruding modeled carrier component by 0.37 mm; the rear plate has 0.25 mm clearance. This permits vertical sliding without sweeping through connector bodies in the reference model. Actual cable removal and tolerances still apply. No snap arm needs bending. The top of each panel is captured by the cover, with 0.2 mm nominal axial clearance. Rail fit is nominally 0.25 mm per side.
8. Lower the cap and install its two diagonal M6 × 20 screws with nominal 1.6 mm washers. The insert seats include screw-tip clearance. The cap's stops seat on the base; the cap does not bear on the cooler.
9. For header or SIM service, remove the two cover screws, lift the cover and slide out the relevant panel. The SIM socket does not have an external slit. J17 has a dedicated side hatch and a 38 mm wide arched access opening. Confirm electrical pin numbering before installing jumpers; the loose jumper model is not an electrical instruction.

## Every I/O opening has a purpose

The no-GMSL front has an audio window and a network/indicator/power window. The GMSL front replaces the audio window with one shared audio/mini-FAKRA window. It has no dummy GMSL opening or SIM slit. Close connectors are grouped to avoid little unsupported strips between them.

The rear has terminal, HDMI/USB-A and underside USB-C access. The rear windows preserve two 4 mm minimum webs through the 6 mm panel thickness. Housing flanges may remain behind the bezel; the actual mating plug and overmold fit still needs checking. The low rear slot serves **two real USB-C connectors**, not ventilation. The exact bounds and purpose of each window are in [docs/cutout-register.csv](docs/cutout-register.csv) and PDF sheets 4–6. Port openings are service envelopes, not automatic projections of solder tails. Mating overmolds, latches and terminal screwdriver/wire access remain to be checked using the user's actual cables.

## Geometry provenance and missing models

[docs/connector-inventory.csv](docs/connector-inventory.csv) is a **schematic-derived mechanical inventory**, not a full official assembly BOM. No standalone Seeed assembly BOM or complete GMSL STEP was found in the checked product/wiki resources or the relevant public OSHW repository folder. It does not claim exact population or AVL approval for all electronic passives.

The carrier source includes **5176 solids and 158 open shells**. Both are retained in current previews; the initial solid-only mesh omitted open surfaces, including the dual USB-A outer housing and audio shell details. Eight mounting proxy solids are omitted from the display so real fasteners can be seen; four zero-thickness pseudo-solids are excluded from solid collision tests and the detailed assembly export. The untouched original STEP retains them. These exceptions are recorded, not treated as removed connectors.

Not all source CAD is mechanically authoritative. J26's single USB-A body is only 3.81 mm high in the STEP, while its schematic footprint names a 13.85 mm part height. The audio STEP library model is named Cliff FC68125, whereas the schematic names MTEP43-205AAB-19305. A bronze-colored, footprint-height envelope is added for J26; it is a constructed clearance model, not exact vendor CAD. Verify both before final panel printing. The front underside socket was previously mislabeled USB-C: it is the nano-SIM socket J18, and the misleading aperture has been removed.

New source files include NVIDIA's AGX Orin simplified module STEP (20230131 revision) and Amphenol FM4-NZRP-PCB-1 STEP/drawing. The Amphenol body matches Seeed's 22.55 × 12 × 15.7 mm footprint, but the schematic does not name that manufacturer. It is a **candidate**, not a confirmed BOM substitution. The GMSL PCB outline is documented; XY location, port positions, upper component positions and support details remain provisional. Small passives are not individually placed on the reconstructed GMSL model.

[references/sources.json](references/sources.json) records source URLs, retrieval dates and SHA-256 hashes. [docs/model-search.csv](docs/model-search.csv) records successful and missing model searches. Original files are preserved under `references/`. Source licenses remain with their respective owners; no right to redistribute vendor CAD beyond its terms is implied.

## Coordinates and checks

All CAD units are millimeters. In the normalized carrier frame, X starts at the left PCB edge, Y at the front edge and Z at the PCB underside. Convert source STEP coordinates by subtracting `(32.199, -510.506, -1.578)`. Then add `(15,15,20)` to place the PCB in the enclosure. STEP parts use assembly coordinates; STL parts are moved to the print bed and oriented as described above.

The module is rotated −90° around Z, then translated `(48.25,131.5,9.578)` in the normalized carrier frame. Its four mounting points register to the source's 92 × 79 pattern. Nominal board-to-board spacing is 8 mm for Molex 2034560003 / 2048430001; module PCB underside to TTP top is 11.18 mm in NVIDIA's STEP. Thus the nominal cooler seat is enclosure Z40.758, before actual TIM/base offsets.

The reference cooler top is Z90.758 and the rib underside Z102, leaving 11.242 mm nominal clearance. The provisional GMSL PCB top is Z39.178: only 1.58 mm below the cooler seat where their plan views overlap by 4.5 mm. This is **not an established physical clearance** for top components or screw heads. Measure this region before printing the GMSL variant. The actual large cooler may have a 12 V fan, while Seeed documents the original carrier fan header as 5 V: check the fan label and wiring rather than assuming compatibility.

Validation reports are in `exports/`: CAD validity/connectedness, STL watertightness, plastic intersections, carrier intersections and a downward-face print screen. These checks do not establish a slicer-verified support-free print, insert pullout, thermal performance, vibration durability, impact resistance or mounting load capacity. No torque or load rating is assigned. The material must be selected and tested against actual temperatures before powered use in a robot or wall installation.

The compact ZIP contains printable parts and review documents; it omits vendor CAD/PDF files and the large detailed assembly. Source links and full reproduction commands refer to the complete `j501-agx` workspace, which retains those references. Download the detailed assembly separately from the local review.

## Reproduce and review

```bash
python -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python cad/build.py
.venv/bin/python tools/export_open_shells.py
.venv/bin/python tools/check_clearances.py
.venv/bin/python tools/check_shells.py
.venv/bin/python tools/assembly_paths.py
.venv/bin/python tools/print_review.py
.venv/bin/python tools/design_metrics.py
.venv/bin/python tools/check_mounts.py
.venv/bin/python tools/write_docs.py
.venv/bin/python tools/check_sheet.py
.venv/bin/python tools/detailed_assembly.py
.venv/bin/python tools/render.py
python tools/serve_preview.py
```

The BREP and source meshes used by rendering are retained for repeatability. `tools/export_hardware.py` recreates the solid mesh and named overlays. `cad/parameters.json` is the parameter authority; the measurement register records values, evidence, checks and limitations. Rev 0.2 source is archived only for traceability and must not be mixed into the current assembly.
